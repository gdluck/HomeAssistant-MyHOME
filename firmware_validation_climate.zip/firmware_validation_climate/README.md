# Firmware validation data for the climate change (2026-10-07)

`REPORT.md` is the full report (sections 2.1 and 3.1-3.2 cover this pull request).
`results/termo*.tsv` are the WHO 4 replays on bt_termo from MyHomeServer1, F454, F459, F461 and F450
(columns: frame, reply, SCS bus bodies sent, monitor output); `results/spv.tsv` and `results/multi.tsv`
back the energy (`*#18*W*1200##`) and sound (WHO 16 vs WHO 22) findings that are not changed here.
The complete data set, raw logs and harness are in OpenWebNet-HA/OWNd under `docs/firmware_validation/`.
